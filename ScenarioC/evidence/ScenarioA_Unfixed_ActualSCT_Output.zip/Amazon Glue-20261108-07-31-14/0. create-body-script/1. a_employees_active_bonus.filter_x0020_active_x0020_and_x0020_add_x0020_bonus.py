import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from sct_utils import cast
from sct_utils import chkParam
from sct_utils import substParam
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
import variables
def filter_x0020_active_x0020_and_x0020_add_x0020_bonus(connection: dict):
	employees_x0020_csv = spark.read.csv("D:\SSISGlueDemo\fixtures\input\Employees.csv", header="True", sep=",")
	employees_x0020_csv = employees_x0020_csv.select(col("employeeid").alias("employeeid"), col("employeename").alias("employeename"), col("department").alias("department"), col("salary").alias("salary"), col("status").alias("status"))
	employees_x0020_csv.createOrReplaceTempView("active_x0020_filter")
	active_x0020_filter_active_x0020_rows = spark.sql("""SELECT
    *
    FROM active_x0020_filter
    WHERE `status` == 'Active'""")
	active_x0020_filter_conditional_x0020_split_x0020_default_x0020_output = spark.sql("""SELECT
    *
    FROM active_x0020_filter
    WHERE NOT (`status` == 'Active')""")
	active_x0020_filter_active_x0020_rows.createOrReplaceTempView("calculate_x0020_10_x0020_percent_x0020_bonus")
	calculate_x0020_10_x0020_percent_x0020_bonus = spark.sql("""SELECT
    t1.*, CAST((`salary` * 0.10) AS decimal) AS `bonus`
    FROM calculate_x0020_10_x0020_percent_x0020_bonus AS t1""")
	activeemployees_x0020_csv = calculate_x0020_10_x0020_percent_x0020_bonus.select(col("employeeid").alias("employeeid"), col("employeename").alias("employeename"), col("department").alias("department"), col("salary").alias("salary"), col("bonus").alias("bonus"))
	activeemployees_x0020_csv.write.mode("Overwrite").csv("D:\SSISGlueDemo\fixtures\expected\ActiveEmployees_SSIS.csv", header="true", sep=",")
	return

