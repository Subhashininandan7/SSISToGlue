import filter_x0020_active_x0020_and_x0020_add_x0020_bonus
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from sct_utils import cast
from sct_utils import chkParam
from sct_utils import substParam
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
import variables
def a_employees_active_bonus(connection: dict):
	filter_x0020_active_x0020_and_x0020_add_x0020_bonus.filter_x0020_active_x0020_and_x0020_add_x0020_bonus(connection)
	return

