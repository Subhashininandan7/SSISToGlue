# Generated launcher for the actual SCT-derived coordinator; not a reference ETL.
import os
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
import b_csv_customer_order_join_repaired_v2 as coordinator

def main():
    a=getResolvedOptions(sys.argv, ['INPUT_PREFIX','OUTPUT_PREFIX','region_name','TempDir','AwsIamRole'])
    os.environ['MIGRATION_INPUT_PREFIX']=a['INPUT_PREFIX'].rstrip('/')
    os.environ['MIGRATION_OUTPUT_PREFIX']=a['OUTPUT_PREFIX'].rstrip('/')
    coordinator.b_csv_customer_order_join_repaired_v2({})

if __name__=='__main__':
    main()
