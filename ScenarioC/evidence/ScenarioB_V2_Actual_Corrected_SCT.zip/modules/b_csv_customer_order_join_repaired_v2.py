import lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
def b_csv_customer_order_join_repaired_v2(connection: dict):
	lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects.lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects(connection)
	return

