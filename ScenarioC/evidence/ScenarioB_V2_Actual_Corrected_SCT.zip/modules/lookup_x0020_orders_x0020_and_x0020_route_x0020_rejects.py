import os
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
def lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects(connection: dict):
	customers_x0020_csv = spark.read.csv(os.environ["MIGRATION_INPUT_PREFIX"] + "/Customers.csv", header="True", sep=",")
	customers_x0020_csv = customers_x0020_csv.select(col("customerid").alias("customerid"), col("customername").alias("customername"))
	orders_x0020_csv = spark.read.csv(os.environ["MIGRATION_INPUT_PREFIX"] + "/Orders.csv", header="True", sep=",")
	orders_x0020_csv = orders_x0020_csv.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("quantity").alias("quantity"), col("unitprice").alias("unitprice"))
	# /* [25042 - Severity CRITICAL - AWS Glue doesn't support {14D43A4F-D7BD-489D-829E-6DE35750CFE4} component. Perform a manual conversion.] */
	
	csv_customer_merge_join.createOrReplaceTempView("route_x0020_matched_x0020_and_x0020_rejected")
	route_x0020_matched_x0020_and_x0020_rejected_matched_x0020_orders = spark.sql("""SELECT
    *
    FROM route_x0020_matched_x0020_and_x0020_rejected
    WHERE ! isnull(`customername`)""")
	route_x0020_matched_x0020_and_x0020_rejected_rejected_x0020_orders = spark.sql("""SELECT
    *
    FROM route_x0020_matched_x0020_and_x0020_rejected
    WHERE NOT (! isnull(`customername`))""")
	route_x0020_matched_x0020_and_x0020_rejected_rejected_x0020_orders.createOrReplaceTempView("add_x0020_rejection_x0020_reason")
	add_x0020_rejection_x0020_reason = spark.sql("""SELECT
    t1.*, 'CUSTOMER_NOT_FOUND' AS `reason`
    FROM add_x0020_rejection_x0020_reason AS t1""")
	rejected_x0020_orders_x0020_csv = add_x0020_rejection_x0020_reason.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("reason").alias("reason"))
	rejected_x0020_orders_x0020_csv.write.mode("Overwrite").csv(os.environ["MIGRATION_OUTPUT_PREFIX"] + "/RejectedOrders_SSIS.csv", header="true", sep=",")
	route_x0020_matched_x0020_and_x0020_rejected_matched_x0020_orders.createOrReplaceTempView("calculate_x0020_order_x0020_total")
	calculate_x0020_order_x0020_total = spark.sql("""SELECT
    t1.*, CAST((`quantity` * `unitprice`) AS decimal) AS `total`
    FROM calculate_x0020_order_x0020_total AS t1""")
	valid_x0020_orders_x0020_csv = calculate_x0020_order_x0020_total.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("customername").alias("customername"), col("quantity").alias("quantity"), col("unitprice").alias("unitprice"), col("total").alias("total"))
	valid_x0020_orders_x0020_csv.write.mode("Overwrite").csv(os.environ["MIGRATION_OUTPUT_PREFIX"] + "/ValidOrders_SSIS.csv", header="true", sep=",")
	return

