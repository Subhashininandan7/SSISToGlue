import lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from sct_utils import cast
from sct_utils import chkParam
from sct_utils import substParam
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
import variables
def b_orders_customer_lookup(connection: dict):
	sql_1 = substParam("""  IF OBJECT_ID('dbo.DemoForgeCustomers','U') IS NULL
      CREATE TABLE dbo.DemoForgeCustomers (CustomerID varchar(120) NOT NULL PRIMARY KEY, CustomerName varchar(120) NOT NULL);
  DELETE FROM dbo.DemoForgeCustomers;
  BULK INSERT dbo.DemoForgeCustomers FROM 'D:\SSISGlueDemo\fixtures\input\Customers.csv'
  WITH (FIRSTROW=2, FIELDTERMINATOR=',', ROWTERMINATOR='0x0a', CODEPAGE='ACP');
  UPDATE dbo.DemoForgeCustomers SET CustomerName=RTRIM(CustomerName);
""")
	stage_x0020_customers_x0020_csv_x0020_for_x0020_lookup = spark.read.format("jdbc").option("driver", "specify driver").option("url", connection["specify connection"]["JDBC_CONNECTION_URL"]).option("user", connection["specify connection"]["USERNAME"]).option("password", connection["specify connection"]["PASSWORD"]).option("tempdir", args["TempDir"]).option("aws_iam_role", args["AwsIamRole"]).option("query", "SELECT 'executeSessionInitialStatement' AS col1").option("sessionInitStatement", sql_1).load()
	stage_x0020_customers_x0020_csv_x0020_for_x0020_lookup_count = stage_x0020_customers_x0020_csv_x0020_for_x0020_lookup.count()
	lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects.lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects(connection)
	return

