from pyspark.storagelevel import StorageLevel
import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from sct_utils import cast
from sct_utils import chkParam
from sct_utils import substParam
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
import variables
def lookup_x0020_orders_x0020_and_x0020_route_x0020_rejects(connection: dict):
	orders_x0020_csv = spark.read.csv("D:\SSISGlueDemo\fixtures\input\Orders.csv", header="True", sep=",")
	orders_x0020_csv = orders_x0020_csv.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("quantity").alias("quantity"), col("unitprice").alias("unitprice"))
	sql_1 = """SELECT CustomerID, CustomerName FROM dbo.DemoForgeCustomers"""
	customer_x0020_lookup = spark.read.format("jdbc").option("driver", "specify driver").option("url", connection["specify connection"]["JDBC_CONNECTION_URL"]).option("user", connection["specify connection"]["USERNAME"]).option("password", connection["specify connection"]["PASSWORD"]).option("tempdir", args["TempDir"]).option("aws_iam_role", args["AwsIamRole"]).option("query", sql_1).load()
	customer_x0020_lookup.persist(StorageLevel.MEMORY_AND_DISK)
	customer_x0020_lookup_lookup_x0020_match_x0020_output = orders_x0020_csv.join(customer_x0020_lookup, (customer_x0020_lookup.'customerid' == orders_x0020_csv.'customerid'), how='left')
	customer_x0020_lookup_lookup_match_output = customer_x0020_lookup_lookup_x0020_match_x0020_output.where(col("customerid").isNotNull())
	customer_x0020_lookup_lookup_no_match_output = customer_x0020_lookup_lookup_x0020_match_x0020_output.where(col("customerid").isNull())
	customer_x0020_lookup_lookup_x0020_no_x0020_match_x0020_output.createOrReplaceTempView("add_x0020_rejection_x0020_reason")
	add_x0020_rejection_x0020_reason = spark.sql("""SELECT
    t1.*, 'CUSTOMER_NOT_FOUND' AS `reason`
    FROM add_x0020_rejection_x0020_reason AS t1""")
	rejected_x0020_orders_x0020_csv = add_x0020_rejection_x0020_reason.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("reason").alias("reason"))
	rejected_x0020_orders_x0020_csv.write.mode("Overwrite").csv("D:\SSISGlueDemo\fixtures\expected\RejectedOrders_SSIS.csv", header="true", sep=",")
	customer_x0020_lookup_lookup_x0020_match_x0020_output.createOrReplaceTempView("calculate_x0020_order_x0020_total")
	calculate_x0020_order_x0020_total = spark.sql("""SELECT
    t1.*, CAST((`quantity` * `unitprice`) AS decimal) AS `total`
    FROM calculate_x0020_order_x0020_total AS t1""")
	valid_x0020_orders_x0020_csv = calculate_x0020_order_x0020_total.select(col("orderid").alias("orderid"), col("customerid").alias("customerid"), col("customername").alias("customername"), col("quantity").alias("quantity"), col("unitprice").alias("unitprice"), col("total").alias("total"))
	valid_x0020_orders_x0020_csv.write.mode("Overwrite").csv("D:\SSISGlueDemo\fixtures\expected\ValidOrders_SSIS.csv", header="true", sep=",")
	return

