import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import math
from sct_utils import cast
from sct_utils import chkParam
from sct_utils import substParam
from decimal import Decimal
from datetime import datetime
from datetime import time
from dateutil.relativedelta import relativedelta
spark = SparkSession.builder.getOrCreate()
args = getResolvedOptions(sys.argv, ['region_name', 'TempDir', 'AwsIamRole'])
import variables
def c_unsupported_execute_process_ai_demo(connection: dict):
	# /* [25029 - Severity CRITICAL - Task of Microsoft.ExecuteProcess type can't be converted. Perform a manual conversion.] */
	
	return

